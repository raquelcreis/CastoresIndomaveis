var boundaries = require('./index')

console.log(boundaries(-122.345002, 47.667044))
